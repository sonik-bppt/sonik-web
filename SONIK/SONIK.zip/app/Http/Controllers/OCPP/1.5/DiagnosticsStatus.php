<?php

class DiagnosticsStatus
{
    const __default = 'Uploaded';
    const Uploaded = 'Uploaded';
    const UploadFailed = 'UploadFailed';


}
