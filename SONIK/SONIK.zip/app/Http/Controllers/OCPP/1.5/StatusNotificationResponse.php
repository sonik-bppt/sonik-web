<?php

class StatusNotificationResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}
