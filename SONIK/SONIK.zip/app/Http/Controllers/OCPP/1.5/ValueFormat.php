<?php

class ValueFormat
{
    const __default = 'Raw';
    const Raw = 'Raw';
    const SignedData = 'SignedData';


}
