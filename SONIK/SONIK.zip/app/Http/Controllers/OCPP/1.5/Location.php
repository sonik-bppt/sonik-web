<?php

class Location
{
    const __default = 'Inlet';
    const Inlet = 'Inlet';
    const Outlet = 'Outlet';
    const Body = 'Body';


}
