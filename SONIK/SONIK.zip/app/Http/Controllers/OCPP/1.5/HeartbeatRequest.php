<?php

class HeartbeatRequest
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}
