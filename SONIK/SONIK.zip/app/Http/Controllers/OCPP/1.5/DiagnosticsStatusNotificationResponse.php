<?php

class DiagnosticsStatusNotificationResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}
