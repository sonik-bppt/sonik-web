<?php

class RegistrationStatus
{
    const __default = 'Accepted';
    const Accepted = 'Accepted';
    const Rejected = 'Rejected';


}
