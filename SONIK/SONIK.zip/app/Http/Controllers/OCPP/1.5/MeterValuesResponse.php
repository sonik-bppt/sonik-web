<?php

class MeterValuesResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}
