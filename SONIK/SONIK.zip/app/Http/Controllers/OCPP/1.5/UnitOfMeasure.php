<?php

class UnitOfMeasure
{
    const __default = 'Wh';
    const Wh = 'Wh';
    const kWh = 'kWh';
    const varh = 'varh';
    const kvarh = 'kvarh';
    const W = 'W';
    const kW = 'kW';
    const aVar = 'var';
    const kvar = 'kvar';
    const Amp = 'Amp';
    const Volt = 'Volt';
    const Celsius = 'Celsius';


}
