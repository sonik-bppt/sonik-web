<?php

class DataTransferStatus
{
    const __default = 'Accepted';
    const Accepted = 'Accepted';
    const Rejected = 'Rejected';
    const UnknownMessageId = 'UnknownMessageId';
    const UnknownVendorId = 'UnknownVendorId';


}
