<?php

class AuthorizationStatus
{
    const __default = 'Accepted';
    const Accepted = 'Accepted';
    const Blocked = 'Blocked';
    const Expired = 'Expired';
    const Invalid = 'Invalid';
    const ConcurrentTx = 'ConcurrentTx';


}
