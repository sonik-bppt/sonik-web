<?php

class FirmwareStatusNotificationResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}
