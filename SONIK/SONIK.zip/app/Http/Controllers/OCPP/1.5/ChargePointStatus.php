<?php

class ChargePointStatus
{
    const __default = 'Available';
    const Available = 'Available';
    const Occupied = 'Occupied';
    const Faulted = 'Faulted';
    const Unavailable = 'Unavailable';
    const Reserved = 'Reserved';


}
