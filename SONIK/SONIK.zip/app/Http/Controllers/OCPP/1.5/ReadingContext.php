<?php

class ReadingContext
{
    const __default = 'InterruptionBegin';
    const InterruptionBegin = 'Interruption.Begin';
    const InterruptionEnd = 'Interruption.End';
    const SampleClock = 'Sample.Clock';
    const SamplePeriodic = 'Sample.Periodic';
    const TransactionBegin = 'Transaction.Begin';
    const TransactionEnd = 'Transaction.End';


}
