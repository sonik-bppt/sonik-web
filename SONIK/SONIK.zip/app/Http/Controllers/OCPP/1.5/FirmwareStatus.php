<?php

class FirmwareStatus
{
    const __default = 'Downloaded';
    const Downloaded = 'Downloaded';
    const DownloadFailed = 'DownloadFailed';
    const InstallationFailed = 'InstallationFailed';
    const Installed = 'Installed';


}
