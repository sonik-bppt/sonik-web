<?php

class DiagnosticsStatus
{
    const __default = 'Idle';
    const Idle = 'Idle';
    const Uploaded = 'Uploaded';
    const UploadFailed = 'UploadFailed';
    const Uploading = 'Uploading';


}
