<?php

class Reason
{
    const __default = 'EmergencyStop';
    const EmergencyStop = 'EmergencyStop';
    const EVDisconnected = 'EVDisconnected';
    const HardReset = 'HardReset';
    const Local = 'Local';
    const Other = 'Other';
    const PowerLoss = 'PowerLoss';
    const Reboot = 'Reboot';
    const Remote = 'Remote';
    const SoftReset = 'SoftReset';
    const UnlockCommand = 'UnlockCommand';
    const DeAuthorized = 'DeAuthorized';


}
