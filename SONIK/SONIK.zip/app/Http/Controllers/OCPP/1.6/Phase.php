<?php

class Phase
{
    const __default = 'L1';
    const L1 = 'L1';
    const L2 = 'L2';
    const L3 = 'L3';
    const N = 'N';
    const L1N = 'L1-N';
    const L2N = 'L2-N';
    const L3N = 'L3-N';
    const L1L2 = 'L1-L2';
    const L2L3 = 'L2-L3';
    const L3L1 = 'L3-L1';


}
