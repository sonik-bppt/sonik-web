<?php

class Location
{
    const __default = 'Body';
    const Body = 'Body';
    const Cable = 'Cable';
    const EV = 'EV';
    const Inlet = 'Inlet';
    const Outlet = 'Outlet';


}
