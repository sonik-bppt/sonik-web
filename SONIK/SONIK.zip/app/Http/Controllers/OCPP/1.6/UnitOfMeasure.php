<?php

class UnitOfMeasure
{
    const __default = 'Celsius';
    const Celsius = 'Celsius';
    const Fahrenheit = 'Fahrenheit';
    const Wh = 'Wh';
    const kWh = 'kWh';
    const varh = 'varh';
    const kvarh = 'kvarh';
    const W = 'W';
    const kW = 'kW';
    const VA = 'VA';
    const kVA = 'kVA';
    const aVar = 'var';
    const kvar = 'kvar';
    const A = 'A';
    const V = 'V';
    const K = 'K';
    const Percent = 'Percent';


}
